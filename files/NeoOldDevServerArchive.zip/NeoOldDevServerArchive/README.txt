This is neo's entire old dev server archive, before my account got hacked in feb 2024.
WARNING: mentions of swears, vulgar language, and cringe are there, be warned before opening.